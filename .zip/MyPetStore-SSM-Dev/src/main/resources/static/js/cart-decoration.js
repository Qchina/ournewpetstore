$(function () {
    function updateCount() {
        var itemCount = $('tr[class = cart-item]').length;
        $('#count').text(itemCount);
    }

    updateCount();

    $(document).on('click', '#removeItem', function (e) {
        e.preventDefault();
        var itemId = $(this).data('id');
        var productId = $('#productId' + itemId);
        var description = $('#description' + itemId);
        var inStock = $('#inStock' + itemId);
        var quantity = $('#quantity' + itemId);
        var listPrice = $('#listPrice' + itemId);
        var total = $('#total' + itemId);
        var $item = $('#' + itemId);

        if ($item.data('remove') === 'removed') {
            if ($item.attr('class') === 'cart-item') {
                $item.remove();
            }

            $.ajax({
                type: 'GET',
                url: 'removeCartItem?workingItemId=' + itemId,
                success: function (data) {
                    console.log(data);

                    var subTotalFormatted = new Intl.NumberFormat('en-US', {
                        style: 'currency',
                        currency: 'USD',
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    }).format(data);

                    $('#subtotal').text(subTotalFormatted);
                    updateCount();
                },
                error: function (errorMsg) {
                    console.log(errorMsg);
                }
            });
        } else {
            if ($item.attr('class') === 'cart-item') {
                $item.remove();
            }

            var innerHTML = '';
            innerHTML += '<tr class="cart-item" id="' + itemId + '" data-remove="removed" ' +
                'style="background-color: #6699ff">';
            innerHTML += '<td style="background-color: #6699ff"><a href="itemForm?itemId='
                + itemId + '" id="itemId' + itemId + '">' + itemId + '</a></td>';
            innerHTML += '<td style="background-color: #6699ff" id="productId' + itemId + '">' + productId.text() + '</td>';
            innerHTML += '<td style="background-color: #6699ff" id="description' + itemId + '">' + description.text() + '</td>';
            innerHTML += '<td style="background-color: #6699ff" id="inStock' + itemId + '">' + inStock.text() + '</td>';
            innerHTML += '<td style="width: 180px; background-color: #6699ff"> <span class="group">';
            innerHTML += '<img src="images/reduce-btn.png" height="30" width="30" class="reduce" ' +
                'data-itemId="' + itemId + '"/>&nbsp;';
            innerHTML += '<input type="text" class="quantity" id="quantity' + itemId + '" name="'
                + itemId + '" value="' + quantity.val() + '"/>';
            innerHTML += '<img src="images/add.png" height="25" width="25" class="add" ' +
                'data-itemId="' + itemId + '"/>';
            innerHTML += '</span></td>'
            innerHTML += '<td style="background-color: #6699ff" id="listPrice' + itemId + '">' + listPrice.text() + '</td>';
            innerHTML += '<td style="background-color: #6699ff"><span id="total' + itemId + '">' + total.text() + '</span></td>';
            innerHTML += '<td style="background-color: #6699ff"> <a href="removeCartItem?workingItemId='
                + itemId + '" ' + 'class="Button" id="removeItem" data-id="' + itemId + '">Remove</a> </td>';
            innerHTML += '</tr>';

            var $lastRow = $('#last-row');
            $lastRow.before(innerHTML);
        }
    });

    $(document).on('click', '.reduce', function () {
        var itemId = $(this).data('itemid');
        var $quantityInput = $('#quantity' + itemId);
        var quantity = $quantityInput.val();
        $quantityInput.val(--quantity);

        if ($quantityInput.val() === '0') {
            console.log("?")
            var $item = $('#' + itemId);
            if ($item.attr('class') === 'cart-item') {
                $item.remove();
            }

            $.ajax({
                type: 'GET',
                url: 'removeCartItem?workingItemId=' + itemId,
                success: function (data) {
                    console.log(data);

                    var subTotalFormatted = new Intl.NumberFormat('en-US', {
                        style: 'currency',
                        currency: 'USD',
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    }).format(data);

                    $('#subtotal').text(subTotalFormatted);
                    updateCount();
                },
                error: function (errorMsg) {
                    console.log(errorMsg);
                }
            });
        } else {
            $.ajax({
                type : 'GET',
                url : 'returnCartItemQuantity?itemId=' + itemId + '&quantity=' + $quantityInput.val(),
                success : function (data) {
                    console.log(data);

                    var totalFormatted = new Intl.NumberFormat('en-US', {
                        style: 'currency',
                        currency: 'USD',
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    }).format(data.total);

                    var subTotalFormatted = new Intl.NumberFormat('en-US', {
                        style: 'currency',
                        currency: 'USD',
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    }).format(data.subTotal);

                    $('#total' + itemId).text(totalFormatted);
                    $('#subtotal').text(subTotalFormatted);
                },
                error : function (errorMsg) {
                    console.log(errorMsg);
                }
            });
        }
    });

    $(document).on('click', '.add', function () {
        var itemId = $(this).data('itemid');
        var $quantityInput = $('#quantity' + itemId);
        var quantity = $quantityInput.val();
        $quantityInput.val(++quantity);

        $.ajax({
            type : 'GET',
            url : 'returnCartItemQuantity?itemId=' + itemId + '&quantity=' + $quantityInput.val(),
            success : function (data) {
                console.log(data);

                var totalFormatted = new Intl.NumberFormat('en-US', {
                    style: 'currency',
                    currency: 'USD',
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }).format(data.total);

                var subTotalFormatted = new Intl.NumberFormat('en-US', {
                    style: 'currency',
                    currency: 'USD',
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }).format(data.subTotal);

                $('#total' + itemId).text(totalFormatted);
                $('#subtotal').text(subTotalFormatted);
            },
            error : function (errorMsg) {
                console.log(errorMsg);
            }
        });
    });
});