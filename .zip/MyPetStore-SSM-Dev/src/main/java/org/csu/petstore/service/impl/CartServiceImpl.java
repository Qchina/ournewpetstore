package org.csu.petstore.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.csu.petstore.entity.Cart;
import org.csu.petstore.persistence.CartMapper;
import org.csu.petstore.persistence.ItemQuantityMapper;
import org.csu.petstore.service.CartService;
import org.csu.petstore.service.CatalogService;
import org.csu.petstore.vo.CartItem;
import org.csu.petstore.vo.CartItemListMapper;
import org.csu.petstore.vo.ItemVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service("cartService")
public class CartServiceImpl implements CartService {

    @Autowired
    private CartMapper cartMapper;

    @Autowired
    private ItemQuantityMapper itemQuantityMapper;

    @Autowired
    private CatalogService catalogService;

    @Override
    public List<Cart> getCartListByUsername(String username) {
        QueryWrapper<Cart> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        return cartMapper.selectList(queryWrapper);
    }

    @Override
    public CartItemListMapper getCartItemListByUsername(String username) {
        CartItemListMapper cartItemListMapper = new CartItemListMapper();
        List<CartItem> cartItemList = new ArrayList<>();
        QueryWrapper<Cart> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        List<Cart> cartList = cartMapper.selectList(queryWrapper);
        for (Cart cart : cartList) {
            CartItem cartItem = new CartItem();
            cartItem.setCart(cart);
            ItemVO itemVO = catalogService.getItem(cart.getItemId());
            cartItem.setItemVO(itemVO);
            cartItem.setInStock(itemQuantityMapper.selectById(cart.getItemId()).getQuantity());
            cartItem.setTotal((itemVO.getListPrice().multiply(new BigDecimal(cart.getQuantity()))));
            cartItemList.add(cartItem);
        }
        cartItemListMapper.setCartItemList(cartItemList);
        return cartItemListMapper;
    }

    @Override
    public void addItemToCart(String username, String itemId) {
        QueryWrapper<Cart> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username).eq("itemId", itemId);
        Cart cart = cartMapper.selectOne(queryWrapper);
        if (cart != null) {
            cart.setQuantity(cart.getQuantity() + 1);
            cartMapper.updateById(cart);
        } else {
            Cart newCart = new Cart();
            newCart.setUsername(username);
            newCart.setItemId(itemId);
            newCart.setQuantity(1);
            cartMapper.insert(newCart);
        }
    }

    @Override
    public void updateCartItemQuantity(String username, String itemId, int quantity) {
        QueryWrapper<Cart> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username).eq("itemId", itemId);
        Cart cart = cartMapper.selectOne(queryWrapper);
        if (cart != null) {
            cart.setQuantity(quantity);
            cartMapper.updateById(cart);
        }
    }

    @Override
    public void removeItem(String username, String itemId) {
        QueryWrapper<Cart> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username).eq("itemId", itemId);
        cartMapper.delete(queryWrapper);
    }

    @Override
    public void clearCart(String username) {
        QueryWrapper<Cart> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        cartMapper.delete(queryWrapper);

    }

    @Override
    public void updateCartByCartItemList(List<CartItem> cartItemList, String username) {
        for (CartItem cartItem : cartItemList) {
            Cart cart = cartItem.getCart();
            int quantity = cart.getQuantity();
            if (quantity < 1) {
                removeItem(username, cart.getItemId());
            } else {
                updateCartItemQuantity(username, cart.getItemId(), quantity);
            }
        }
    }
}