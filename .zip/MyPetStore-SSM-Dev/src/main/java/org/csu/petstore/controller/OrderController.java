package org.csu.petstore.controller;

import jakarta.servlet.http.HttpSession;
import org.csu.petstore.entity.Order;
import org.csu.petstore.service.CartService;
import org.csu.petstore.service.OrderService;
import org.csu.petstore.vo.AccountVO;
import org.csu.petstore.vo.CartItemListMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import java.math.BigDecimal;
import java.util.List;

@Controller
@RequestMapping("/order")
public class OrderController {
    @Autowired
    private OrderService orderService;

    @Autowired
    private CartService cartService;

    @Autowired
    private HttpSession session;

    @GetMapping("/newOrder")
    public String newOrder(Model model) {
        Order order = new Order();
        session.setAttribute("order", order);
        AccountVO account = (AccountVO) session.getAttribute("account");
        model.addAttribute("loginAccount", account);
        model.addAttribute("order", order);
        session.setAttribute("loginAccount", account);
        return "order/newOrder";
    }

    @PostMapping("/confirmOrder")
    public String confirmOrder(@ModelAttribute("order") Order order, Model model) {
        AccountVO account = (AccountVO) session.getAttribute("loginAccount");
        String userId = account.getUsername();
        order.setUsername(userId);
        order.setTotalPrice((BigDecimal) session.getAttribute("subTotal"));
        orderService.insertOrder(order,account);
        session.setAttribute("order", order);
        cartService.clearCart(userId);
        return "order/confirmOrder";
    }
    @GetMapping("/viewOrder")
    public String viewOrder(Model model) {
        Order order = (Order) session.getAttribute("order");
        CartItemListMapper cartItemListMapper = (CartItemListMapper) session.getAttribute("cartItemListMapper");
        orderService.finishOrder(order,cartItemListMapper);
        return "catalog/main";
    }
    @GetMapping("/listOrder")
    public String listOrder(String username,Model model) {
        List<Order> orderList = orderService.getOrdersByUsername(username);
        model.addAttribute("orderList", orderList);
        return "order/listOrder";
    }

}

