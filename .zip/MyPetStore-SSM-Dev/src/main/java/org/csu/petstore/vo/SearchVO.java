package org.csu.petstore.vo;

import lombok.Data;

@Data
public class SearchVO {
    private String searchId;
    private String searchName;
    private String descriptionImage;
    private String descriptionText;
}