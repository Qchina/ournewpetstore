package org.csu.petstore.service;

import org.csu.petstore.entity.Log;

public interface LogService {
    void saveLog(Log Log);
}